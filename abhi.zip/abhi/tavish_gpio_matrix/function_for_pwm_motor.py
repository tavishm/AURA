from matrix_lite import gpio

def move(ss, freq=100, per=70):
	exit()
	if per>70:
		exit()
	for i in (0,1,2,3):
		gpio.setFunction(i, 'PWM')
		gpio.setMode(i, "output")
	if ss == 'front':
		print('Moving forward')
		gpio.setPWM({"pin": 0,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 1,"percentage":per,"frequency":freq})
		gpio.setPWM({"pin": 2,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 3,"percentage":per,"frequency":freq})

	elif ss == 'back':
		print('Moving backward')
		gpio.setPWM({"pin": 0,"percentage":per,"frequency":freq})
		gpio.setPWM({"pin": 1,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 2,"percentage":per,"frequency":freq})
		gpio.setPWM({"pin": 3,"percentage":0,"frequency":freq})

	elif ss == 'right':
		print('Moving right')
		gpio.setPWM({"pin": 0,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 1,"percentage":per,"frequency":freq})
		gpio.setPWM({"pin": 2,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 3,"percentage":0,"frequency":freq})

	elif ss == 'left':
		print('Moving left')
		gpio.setPWM({"pin": 0,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 1,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 2,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 3,"percentage":per,"frequency":freq})
	else:
		print('Exiting')
		gpio.setPWM({"pin": 0,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 1,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 2,"percentage":0,"frequency":freq})
		gpio.setPWM({"pin": 3,"percentage":0,"frequency":freq})

