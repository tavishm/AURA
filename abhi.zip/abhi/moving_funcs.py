import RPi.GPIO as GPIO
class move_funcs:
	def speed_cotrol(speed):
		GPIO.
